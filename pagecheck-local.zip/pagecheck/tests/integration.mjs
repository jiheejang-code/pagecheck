import {spawn} from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import os from 'node:os';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),PORT=Number(process.env.TEST_PORT||47832),base=`http://127.0.0.1:${PORT}`,token='pagecheck-test-token-not-production';
const temp=path.join(ROOT,'.local','integration-'+Date.now());await fs.mkdir(temp,{recursive:true});
const fixture=path.join(ROOT,'dist/fixtures/review-fixture.html');await fs.mkdir(path.dirname(fixture),{recursive:true});
const broken=`<!doctype html><html><meta charset="utf-8"><title>서비스 신청 — 검사 예시</title><style>body{margin:0;background:#f1f4f7;color:#203b4b;font-family:Arial,sans-serif}header{background:#193746;color:white;padding:27px 90px}main{max-width:820px;margin:45px auto;background:white;padding:40px;border-radius:12px}h1{font-size:29px}label{display:block;margin:20px 0 8px}input{padding:12px;border:1px solid #ccc;border-radius:5px;width:90%}.low{color:#c6c6c6}.submit{background:#1c6c51;color:white;border:0;padding:12px 25px;border-radius:5px;margin-top:23px}button.blank{width:38px;height:34px;border:1px solid #ccd4d8;background:#f5f7f9;border-radius:4px}.card{cursor:pointer;padding:8px}.plain{border:0;background:none;padding:6px}.plain:focus{outline:none}.clip{width:600px;max-width:100%;height:20px;line-height:20px;overflow:hidden}.wide{width:600px;background:#eef3f6}</style><header>DEMO SERVICE · 예시 페이지</header><main><img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48'%3E%3Crect width='48' height='48' rx='10' fill='%231c6c51'/%3E%3C/svg%3E"><h1>서비스 이용 신청</h1><p class="low">본 페이지는 검수 기능 확인용 예시입니다.</p><form><p>신청자 이름</p><input><label for="email">이메일</label><input id="email" type="email"><p><button type="button" class="blank"></button></p><button class="submit" type="button">신청하기</button></form><section><div class="card" onclick="void 0">상세 보기</div><button class="plain" type="button">더 보기</button><div class="clip">신청 전에 꼭 읽어 주세요.</div><div class="wide">신청 안내 표</div></section></main></html>`;
const fixed=broken.replace('<html>','<html lang="ko">').replace('<img src=','<img alt="" src=').replace('color:#c6c6c6','color:#586573').replace('<p>신청자 이름</p><input','<label for="name">신청자 이름</label><input id="name"').replace('class="blank"></button>','class="blank" aria-label="추가 옵션">＋</button>')
 .replace('<div class="card" onclick="void 0">상세 보기</div>','<button class="card" type="button">상세 보기</button>').replace('.plain:focus{outline:none}','.plain:focus{outline:2px solid #1c6c51}').replace('height:20px;line-height:20px;overflow:hidden','min-height:20px').replace('.wide{width:600px;','.wide{max-width:600px;');
await fs.writeFile(fixture,broken);
const proc=spawn(process.execPath,['engine/server.mjs'],{cwd:ROOT,env:{...process.env,PORT:String(PORT),PAGECHECK_TOKEN:token,PAGECHECK_DATA:temp},windowsHide:true,stdio:['ignore','pipe','pipe']});
let errs='';proc.stderr.on('data',x=>errs+=x);proc.stdout.resume();
const delay=n=>new Promise(r=>setTimeout(r,n));
async function req(route,body,method){const response=await fetch(base+route,{method:method|| (body?'POST':'GET'),headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:body?JSON.stringify(body):undefined});return {status:response.status,body:await response.json()}}
async function complete(id){for(let i=0;i<200;i++){const r=(await req('/api/runs/'+id)).body;if(!['running','queued'].includes(r.status))return r;await delay(400)}throw Error('scan timed out')}
const checks=[];const ok=(name,value)=>{assert(value,name);checks.push({name,passed:true})};let context;
try{
 for(let i=0;i<70;i++){try{if((await fetch(base+'/api/health')).ok)break}catch{}await delay(150)}
 ok('health endpoint', (await fetch(base+'/api/health')).ok);
 ok('API rejects unauthenticated result access',(await fetch(base+'/api/runs')).status===401);
 ok('API rejects unsupported URL protocol',(await req('/api/runs',{url:'javascript:alert(1)'})).status===400);
 const start=await req('/api/runs',{name:'검사 예시',url:base+'/fixtures/review-fixture.html',environment:'demo',mode:'quick'});ok('new review queued',start.status===202);
 const first=await complete(start.body.id);ok('browser scan completed',first.status==='completed');ok('real violations detected',first.issues.some(i=>i.ruleId==='label')&&first.issues.some(i=>i.ruleId==='button-name'));ok('55 criteria never auto-passed',first.summary.assessed===0&&first.coverage.every(c=>c.outcome!=='pass'));
 ok('every criterion has manual check steps',first.coverage.length===55&&first.coverage.every(c=>c.how.length>0));
 const suggested=first.coverage.filter(c=>c.suggest).map(c=>c.id);
 ok('media criteria suggested as not applicable',['1.2.1','1.2.2','1.2.3','1.2.4','1.2.5','1.4.2'].every(id=>suggested.includes(id)));
 ok('form criteria not suggested when inputs exist',!suggested.includes('3.3.2')&&first.states.every(s=>s.facts.form>0));
 ok('suggestion is not a recorded outcome',first.coverage.filter(c=>c.suggest).every(c=>c.outcome==='not-tested'&&!c.review)&&first.summary.naSuggested===suggested.length);
 const pc=first.issues.filter(i=>i.source==='pagecheck'),has=id=>pc.some(i=>i.ruleId===id);
 ok('keyboard and zoom checks completed',first.checks.length===4&&first.checks.every(k=>k.status==='completed'&&k.screenshot));
 ok('keyboard check finds hidden focus and mouse-only element',has('pc-focus-visible')&&has('pc-pointer-only'));
 ok('reflow and text spacing checks find candidates',has('pc-reflow-overflow')&&has('pc-spacing-clip')&&!has('pc-zoom-overflow'));
 ok('check candidates need human review not violations',pc.every(i=>i.type==='review'&&i.bounds&&i.screenshot));
 ok('criteria show check evidence',['2.1.1','2.4.3','2.4.7','1.4.10','1.4.4','1.4.12'].every(id=>first.coverage.find(c=>c.id===id).evidence.length>0)&&first.coverage.every(c=>c.outcome!=='pass'));
 const one=first.issues.find(i=>i.type==='violation'&&i.scIds.length);ok('violation has source and evidence',!!one.screenshot&&!!one.helpUrl&&!!one.bounds);
 ok('manual pass cannot override unresolved violation',(await req('/api/runs/'+first.id+'/review',{scId:one.scIds[0],outcome:'pass',note:'test',reviewer:'QA'})).status===400);
 ok('issue workflow saved',(await req('/api/runs/'+first.id+'/issues/'+one.id,{workflow:'inprogress',owner:'QA',note:'수정 중'},'PATCH')).body.issues.find(i=>i.id===one.id).owner==='QA');
 const sample=structuredClone(first);sample.request.name='서비스 신청 페이지 · 예시';sample.request.changeNote='의도적으로 문제를 넣은 예시 페이지의 실제 자동 검사 결과';sample.request.environment='demo';sample.sample=true;
 await fs.writeFile(path.join(ROOT,'dist/sample-run.json'),JSON.stringify(sample,null,2));
 await fs.copyFile(path.join(temp,'evidence',one.screenshot),path.join(ROOT,'dist/sample-evidence.png'));
 for(const k of first.checks)await fs.copyFile(path.join(temp,'evidence',k.screenshot),path.join(ROOT,`dist/sample-${k.kind}.png`));
 const manual=await req('/api/runs/'+first.id+'/review',{scId:'1.3.2',outcome:'fail',note:'사람 검토에서 읽기 순서 문제 확인',reviewer:'QA'});
 ok('manual criterion failure creates actionable issue',manual.body.issues.some(i=>i.source==='manual')&&manual.body.summary.assessed===1);
 await fs.writeFile(fixture,fixed);const repeat=await req('/api/runs/'+first.id+'/recheck',{});const second=await complete(repeat.body.id);
 ok('recheck detects resolved issues',second.comparison.resolved.includes(one.fingerprint));ok('unchanged issues not fabricated',second.comparison.new.length===0);ok('baseline issue resolved only after recheck',(await req('/api/runs/'+first.id)).body.issues.find(i=>i.id===one.id).workflow==='resolved');
 ok('recheck resolves fixed check candidates',pc.every(i=>second.comparison.resolved.includes(i.fingerprint)));
 ok('manual findings never auto-resolve',second.issues.some(i=>i.source==='manual'&&i.workflow==='open'));
 const fail=await req('/api/runs',{name:'접속 실패 예시',url:base+'/fixtures/nonexistent.html',mode:'quick'});const missing=await complete(fail.body.id);ok('HTTP failure is untested not pass',missing.status==='failed'&&missing.summary.errors===1&&missing.summary.assessed===0);
 ok('quick mode rejects excess URLs',(await req('/api/runs',{urls:[base+'/fixtures/review-fixture.html',base+'/'],mode:'quick'})).status===400);
 const release=await req('/api/runs',{name:'PC·모바일 단계 검사',url:base+'/fixtures/review-fixture.html',mode:'release',steps:[{action:'click',selector:'.blank',label:'옵션 버튼 클릭'}]});
 const releaseDone=await complete(release.body.id);ok('release scans desktop/mobile and registered states',releaseDone.states.filter(s=>s.status==='completed').length===4&&releaseDone.states.some(s=>s.viewport==='mobile'&&s.step===1));
 const badStep=await req('/api/runs',{name:'미구현 단계',url:base+'/fixtures/review-fixture.html',steps:[{action:'click',selector:'.not-implemented'}]});
 const stepResult=await complete(badStep.body.id);ok('unimplemented step is untested not auto-exempt',stepResult.states.some(s=>s.status==='error'&&s.step===1));
 // Comparison must not label unreachable states as fixed.
 await fs.writeFile(fixture,broken);const again=await req('/api/runs',{name:'비교 범위 예시',url:base+'/fixtures/review-fixture.html'});const third=await complete(again.body.id);await fs.rename(fixture,fixture+'.temp');
 const failedRepeat=await req('/api/runs/'+third.id+'/recheck',{});const unverified=await complete(failedRepeat.body.id);ok('failed recheck preserves unresolved issues',unverified.comparison.resolved.length===0&&unverified.comparison.unverified.length===third.issues.length);await fs.rename(fixture+'.temp',fixture);
 let pw;try{pw=createRequire(import.meta.url)('playwright')}catch{pw=createRequire(path.join(os.homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/package.json'))('playwright')}
 context=await pw.chromium.launchPersistentContext(path.join(temp,'ui-profile'),{headless:true,channel:'chrome',viewport:{width:1440,height:1050}});const page=await context.newPage();const pageErrors=[];page.on('pageerror',e=>pageErrors.push(e.message));
 await page.goto(base);await page.addScriptTag({path:path.join(ROOT,'engine/vendor/axe.min.js')});
 const ownAudit=await page.evaluate(async()=>{const r=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']}});return r.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>n.target)}))});
 if(ownAudit.length)console.log(JSON.stringify({ownAudit}));ok('tool dashboard passes selected automatic accessibility rules',ownAudit.length===0);
 await page.getByRole('button',{name:'예시 결과 둘러보기'}).click();
 await page.waitForSelector('.issue-card');ok('sample explicitly labelled',await page.locator('.banner').textContent().then(x=>x.includes('예시 데이터')));await page.screenshot({path:path.join(ROOT,'.local/result-desktop.png')});
 await page.getByRole('tab',{name:'기준별 평가'}).click();ok('UI displays all 55 criteria',await page.locator('.coverage-row').count()===55);
 await page.getByRole('button',{name:'검수 목록으로'}).click();await page.getByRole('button',{name:'새 검수',exact:true}).click();await page.getByLabel('검수 이름',{exact:true}).fill('브라우저 UI 검수');await page.locator('#scan-urls').fill(base+'/fixtures/review-fixture.html');
 await page.getByRole('button',{name:'검수 시작',exact:true}).click();await page.waitForSelector('.result-heading');ok('UI submits a real review',await page.locator('h1').textContent()==='브라우저 UI 검수');
 // Recheck connection at submission and preserve the draft on failure.
 await page.getByRole('button',{name:'검수 목록으로'}).click();
 await page.route('**/api/health',route=>route.abort('failed'));
 await page.getByRole('button',{name:'새 검수',exact:true}).click();
 await page.getByLabel('검수 이름',{exact:true}).fill('연결 복구 검수');await page.locator('#scan-urls').fill(base+'/fixtures/review-fixture.html');
 ok('start remains actionable before connection recheck',await page.getByRole('button',{name:'검수 시작',exact:true}).isEnabled());
 await page.getByRole('button',{name:'검수 시작',exact:true}).click();await page.locator('#form-error').filter({hasText:'검사 엔진에 연결할 수 없습니다'}).waitFor();
 ok('connection failure explains next step and preserves input',await page.locator('#scan-name').inputValue()==='연결 복구 검수'&&await page.getByRole('button',{name:'검수 시작',exact:true}).isEnabled());
 await page.unroute('**/api/health');await page.locator('details').first().evaluate(el=>el.open=true);await page.locator('#api-token').fill('incorrect-test-key');
 await page.getByRole('button',{name:'검수 시작',exact:true}).click();await page.locator('#form-error').filter({hasText:'연결 키를 확인하세요'}).waitFor();
 ok('stale key reported without losing review draft',await page.locator('#scan-name').inputValue()==='연결 복구 검수');
 await page.locator('#api-token').fill(token);await page.getByRole('button',{name:'검수 시작',exact:true}).click();await page.waitForSelector('.result-heading');
 ok('retry after restoring connection starts actual scan',await page.locator('h1').textContent()==='연결 복구 검수');
 await page.screenshot({path:path.join(ROOT,'.local/dashboard-live.png')});await page.getByRole('button',{name:'검수 목록으로'}).click();await page.screenshot({path:path.join(ROOT,'.local/dashboard-desktop.png')});
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(ROOT,'.local/dashboard-mobile.png')});ok('mobile does not horizontally overflow',await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));ok('no page JavaScript errors',pageErrors.length===0);
 await context.close();context=null;
 await fs.writeFile(path.join(ROOT,'test-results.json'),JSON.stringify({at:new Date().toISOString(),checks,passed:checks.length},null,2));console.log(JSON.stringify({passed:checks.length,checks:checks.map(c=>c.name)}));
}finally{if(context)await context.close();proc.kill();await delay(400);if(errs)console.error(errs.slice(-1500));}

