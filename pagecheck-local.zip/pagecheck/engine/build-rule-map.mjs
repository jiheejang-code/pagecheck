// axe 규칙표(dist/axe-rules.json)를 만든다: 규칙 ID → 연결된 WCAG 성공 기준과 한국어 규칙 이름. axe를 바꾸면 다시 실행한다.
import {chromium} from 'playwright';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const ko=JSON.parse(await fs.readFile(path.join(ROOT,'engine/vendor/axe-ko.json'),'utf8'));
const browser=await chromium.launch({channel:process.env.PAGECHECK_BROWSER||'chrome'}).catch(()=>chromium.launch({channel:'msedge'}));
const page=await browser.newPage();
await page.addScriptTag({path:path.join(ROOT,'engine/vendor/axe.min.js')});
const map=await page.evaluate(()=>({version:axe.version,rules:Object.fromEntries(axe.getRules(['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']).filter(r=>!r.tags.includes('experimental')).map(r=>[r.ruleId,{
 sc:r.tags.filter(t=>/^wcag\d{3,4}$/.test(t)).map(t=>{const s=t.slice(4);return s[0]+'.'+s[1]+'.'+s.slice(2)}),help:r.help}]))}));
await browser.close();
// axe 한국어 번역에 없는 규칙의 이름
const extraKo={
 'aria-braille-equivalent':'점자용 aria 속성에는 점자가 아닌 대응 속성이 함께 있어야 합니다.',
 'aria-conditional-attr':'ARIA 속성은 요소의 역할에 맞게 사용해야 합니다.',
 'aria-deprecated-role':'더 이상 쓰지 않는 ARIA 역할을 사용하면 안 됩니다.',
 'aria-prohibited-attr':'요소에 허용된 ARIA 속성만 사용해야 합니다.',
 'summary-name':'summary 요소에는 알아볼 수 있는 텍스트가 있어야 합니다.',
 'target-size':'터치 대상은 24px 이상이거나 주변에 충분한 간격이 있어야 합니다.'};
for(const [id,r] of Object.entries(map.rules))r.help=ko.rules[id]?.help||extraKo[id]||r.help;
await fs.writeFile(path.join(ROOT,'dist/axe-rules.json'),JSON.stringify(map,null,1)+'\n');
console.log(`axe ${map.version}: 규칙 ${Object.keys(map.rules).length}개, 한국어 이름 ${Object.keys(map.rules).filter(id=>ko.rules[id]?.help).length}개`);
