// axe 규칙 ID → WCAG 성공 기준 연결표(engine/axe-rule-sc.json)를 만든다. axe를 바꾸면 다시 실행한다.
import {chromium} from 'playwright';
import fs from 'node:fs/promises';
const ROOT=new URL('..',import.meta.url);
const browser=await chromium.launch({channel:process.env.PAGECHECK_BROWSER||'chrome'}).catch(()=>chromium.launch({channel:'msedge'}));
const page=await browser.newPage();
await page.addScriptTag({path:new URL('engine/vendor/axe.min.js',ROOT).pathname.replace(/^\/([A-Za-z]:)/,'$1')});
const map=await page.evaluate(()=>({version:axe.version,rules:Object.fromEntries(axe.getRules(['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']).filter(r=>!r.tags.includes('experimental')).map(r=>[r.ruleId,r.tags.filter(t=>/^wcag\d{3,4}$/.test(t)).map(t=>{const s=t.slice(4);return s[0]+'.'+s[1]+'.'+s.slice(2)})]))}));
await browser.close();
await fs.writeFile(new URL('engine/axe-rule-sc.json',ROOT),JSON.stringify(map,null,1)+'\n');
console.log(`axe ${map.version}: 규칙 ${Object.keys(map.rules).length}개`);
