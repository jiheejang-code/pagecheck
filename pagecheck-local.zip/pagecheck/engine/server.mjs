import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const DATA=path.resolve(process.env.PAGECHECK_DATA||path.join(ROOT,'data'));
const PORT=Number(process.env.PORT||47831), ORIGIN=`http://127.0.0.1:${PORT}`;
const hosted='https://pagecheck-review-jihee.injangin.chatgpt.site';
const allowedOrigins=new Set([ORIGIN,`http://localhost:${PORT}`,hosted,...(process.env.PAGECHECK_ALLOWED_ORIGINS||'').split(',').filter(Boolean)]);
const TOKEN=process.env.PAGECHECK_TOKEN||crypto.randomBytes(24).toString('hex');
await fsp.mkdir(DATA,{recursive:true});
const CRITERIA=JSON.parse(await fsp.readFile(path.join(ROOT,'engine/criteria.json'),'utf8')).filter(x=>x.wcag22_aa_scope);
// 자동 규칙이 하나라도 연결된 성공 기준. 규칙표(dist/axe-rules.json)는 engine/build-rule-map.mjs로 만든다.
const AUTO_SC=new Set(Object.values(JSON.parse(await fsp.readFile(path.join(ROOT,'dist/axe-rules.json'),'utf8')).rules).flatMap(r=>r.sc));
// 기준별 사람 확인 안내(how)와 '해당 없음'을 제안할 수 있는 페이지 조건(na).
const GUIDE=JSON.parse(await fsp.readFile(path.join(ROOT,'engine/manual-guide.json'),'utf8')).criteria;
for(const c of CRITERIA)if(!GUIDE[c.sc_id]?.how?.length)console.warn(`확인 안내 없음: ${c.sc_id}`);
const NA_TEXT={media:['동영상·오디오가','video·audio·embed 요소와 동영상 iframe'],form:['입력 칸이','input·select·textarea·편집 가능 영역과 입력 역할(role) 요소']};
const AXE_KO=JSON.parse(await fsp.readFile(path.join(ROOT,'engine/vendor/axe-ko.json'),'utf8'));
const RUNFILE=path.join(DATA,'runs.json');
let runs=[];try{runs=JSON.parse(await fsp.readFile(RUNFILE,'utf8'))}catch{}
for(const r of runs)if(['queued','running'].includes(r.status)){r.status='interrupted';r.logs.push({at:new Date().toISOString(),message:'검사 엔진 재시작으로 중단됨. 재검수를 실행하세요.'})}
const rawRequests=new Map(), sessions=new Map(),queue=[];let busy=false;
let playwright;
try{playwright=createRequire(import.meta.url)('playwright')}
catch{try{playwright=createRequire(path.join(os.homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/package.json'))('playwright')}catch{}}
let writeChain=Promise.resolve();
const persist=()=>{const snapshot=JSON.stringify(runs,null,2);writeChain=writeChain.catch(()=>{}).then(async()=>{const tmp=RUNFILE+'.tmp';await fsp.writeFile(tmp,snapshot);await fsp.rename(tmp,RUNFILE)});return writeChain};
const hash=x=>crypto.createHash('sha256').update(x).digest('hex').slice(0,20);
const now=()=>new Date().toISOString();
function safeUrl(value){const u=new URL(value);if(!['http:','https:'].includes(u.protocol)||u.username||u.password)throw Error('HTTP(S) 주소를 입력하세요. 주소에 계정 정보를 넣을 수 없습니다.');if(['169.254.169.254','metadata.google.internal'].includes(u.hostname))throw Error('이 주소는 검사 대상이 아닙니다.');return u.href}
function normalize(body){
 const mode=['quick','release','monitor'].includes(body.mode)?body.mode:'quick';
 const urls=[...new Set((body.urls||[body.url]).filter(Boolean).map(x=>safeUrl(String(x).trim())))];
 if(!urls.length)throw Error('검수할 주소를 입력하세요.');const limit=mode==='quick'?1:mode==='release'?8:5;
 if(urls.length>limit)throw Error(`이 모드에서는 한 번에 ${limit}개 주소까지 검사합니다.`);
 const steps=body.steps||[];if(!Array.isArray(steps)||steps.length>10)throw Error('검사 단계는 10개 이내로 입력하세요.');
 for(const s of steps)if(!['click','fill','press'].includes(s.action)||!s.selector||s.selector.length>500)throw Error('단계에는 click/fill/press와 selector가 필요합니다.');
 return {name:String(body.name||new URL(urls[0]).hostname).slice(0,100),environment:['demo','development','production'].includes(body.environment)?body.environment:'development',mode,urls,
  changeNote:String(body.changeNote||'').slice(0,2000),implementation:body.implementation==='partial'?'partial':'complete',
  viewports:mode==='quick'?['desktop']:(body.viewports?.length?body.viewports.filter(x=>['desktop','mobile'].includes(x)):['desktop','mobile']),
  steps,sessionId:body.sessionId||null,baselineId:body.baselineId||null};
}
function publicRequest(input){return {...input,steps:input.steps.map(s=>({...s,value:s.action==='fill'?'[실행 시에만 사용]':s.value})),sessionId:input.sessionId?'connected':null}}
function log(run,message){run.logs.push({at:now(),message});run.updatedAt=now()}
function enqueue(input){
 const run={id:crypto.randomUUID(),createdAt:now(),updatedAt:now(),status:'queued',request:publicRequest(input),states:[],issues:[],reviews:{},logs:[],comparison:null,engine:{name:'axe-core',version:'4.10.3',standard:'WCAG 2.2 A·AA',browser:'Chrome',criteriaTarget:55},error:null};
 runs.unshift(run);rawRequests.set(run.id,input);queue.push(run.id);persist().catch(()=>{});drain();return run;
}
function stats(run){
 const active=run.issues.filter(i=>i.workflow!=='resolved');const errors=run.states.filter(s=>s.status==='error');
 const manual=Object.values(run.reviews).filter(r=>['pass','fail','inapplicable'].includes(r.outcome)).length;
 const manualFailure=Object.values(run.reviews).some(r=>r.outcome==='fail');
 return {open:active.filter(i=>i.type==='violation').length,review:active.filter(i=>i.type==='review').length,
  untested:Math.max(0,55-manual),critical:active.filter(i=>i.type==='violation'&&['critical','serious'].includes(i.impact)).length,
  states:run.states.length,errors:errors.length,assessed:manual,
  decision:run.status!=='completed'?'검사 미완료':active.length||manualFailure?'수정·확인 필요':errors.length?'미검사 범위 확인 필요':manual<55?'전체 기준 평가 대기':'검사 범위 내 검토 완료'};
}
function hydrate(run){
 // auto: 자동 검사 결과. issue=문제 발견, clear=규칙 검사에서 문제 없음, not-covered=자동 규칙 없음, null=아직 검사 안 함
 const scanned=run.states.some(s=>s.status==='completed');
 const coverage=CRITERIA.map(c=>{
 const issues=run.issues.filter(i=>i.scIds.includes(c.sc_id)&&i.workflow!=='resolved');
 const outcome=issues.some(i=>i.type==='violation')?'fail':issues.length?'needs-review':run.reviews[c.sc_id]?.outcome||'not-tested';
 const auto=!scanned?null:issues.some(i=>i.source==='axe-core')?'issue':AUTO_SC.has(c.sc_id)?'clear':'not-covered';
 const g=GUIDE[c.sc_id]||{};
 return {id:c.sc_id,title:c.title_ko_unofficial,level:c.level,focus:c.audit_focus_ko,how:g.how||[],url:c.version_source_urls['2.2'],outcome,auto,suggest:outcome==='not-tested'?naSuggestion(run,g.na):null,review:run.reviews[c.sc_id]||null};
 });
 const summary=stats(run);
 if(scanned){const open=coverage.filter(c=>c.outcome==='not-tested');summary.autoClear=open.filter(c=>c.auto==='clear').length;summary.autoNone=open.filter(c=>c.auto==='not-covered').length;summary.naSuggested=open.filter(c=>c.suggest).length}
 return {...run,summary,coverage};
}
// 검사한 모든 화면에서 해당 요소가 0개였을 때만 '해당 없음'을 제안한다. 판정은 사람이 확인해야 기록된다.
// 사실을 못 모은 화면이나 읽지 못한 iframe이 하나라도 있으면 제안하지 않는다.
function naSuggestion(run,kind){
 if(!NA_TEXT[kind])return null;
 const done=run.states.filter(s=>s.status==='completed');
 if(!done.length||done.some(s=>!s.facts||s.facts.unreadFrames>0||s.facts[kind]>0))return null;
 return {outcome:'inapplicable',kind,reason:`검사한 화면 ${done.length}개 모두에서 ${NA_TEXT[kind][0]} 발견되지 않았습니다(${NA_TEXT[kind][1]} 0개).`};
}
// 화면 안의 동영상·오디오와 입력 칸 수. 같은 출처가 아닌 iframe은 읽지 못한 수로 남긴다.
async function pageFacts(page){
 const facts={media:0,form:0,unreadFrames:0};
 for(const frame of page.frames()){
  try{const f=await frame.evaluate(()=>{
   const visible=el=>{const s=getComputedStyle(el);return s.display!=='none'&&s.visibility!=='hidden'&&!el.closest('[hidden],[aria-hidden="true"]')};
   const mediaFrame=/youtube|youtu\.be|vimeo|tv\.naver|kakaotv|tv\.kakao|dailymotion|twitch|wistia|brightcove|jwplayer|soundcloud|spotify|podbbang|player/i;
   const media=[...document.querySelectorAll('video,audio,object,embed')].length+[...document.querySelectorAll('iframe')].filter(x=>mediaFrame.test(x.src||'')).length;
   const form=[...document.querySelectorAll('input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=reset]):not([type=image]),select,textarea,[contenteditable=""],[contenteditable=true],[role=textbox],[role=combobox],[role=searchbox],[role=spinbutton],[role=slider],[role=listbox],[role=checkbox],[role=radio],[role=switch]')].filter(visible).length;
   return {media,form}});facts.media+=f.media;facts.form+=f.form}
  catch{facts.unreadFrames++}
 }
 return facts;
}
// 문제 상세에 보여줄 axe 확인 항목. 명도 대비는 수치와 색상을 함께 남긴다.
const CONTRAST_KEYS=['fgColor','bgColor','shadowColor','contrastRatio','expectedContrastRatio','fontSize','fontWeight'];
function checksOf(node){return ['any','all','none'].flatMap(group=>(node[group]||[]).map(c=>({...c,group}))).slice(0,6).map(c=>({id:c.id,group:c.group,message:String(c.message||'').slice(0,400),
 data:c.id==='color-contrast'&&c.data&&typeof c.data==='object'?Object.fromEntries(CONTRAST_KEYS.filter(k=>c.data[k]!=null).map(k=>[k,String(c.data[k]).slice(0,40)])):null}))}
function toIssue(rule,node,run,state,type){
 const scIds=rule.tags.filter(t=>/^wcag\d{3,4}$/.test(t)).map(t=>{const s=t.slice(4);return s[0]+'.'+s[1]+'.'+s.slice(2)}).filter(x=>CRITERIA.some(c=>c.sc_id===x));
 const selector=node.target.map(t=>typeof t==='string'?t:t.join(' → ')).join(' → ');
 const route=new URL(state.url);const fp=hash(`${rule.id}|${route.pathname}${route.search}|${state.viewport}|${state.step}|${selector}`);
 return {id:fp,fingerprint:fp,ruleId:rule.id,title:rule.help,description:rule.description,impact:rule.impact||'moderate',
  type,workflow:'open',scIds,helpUrl:rule.helpUrl,selector,html:node.html,explanation:node.failureSummary||'도구만으로 확정할 수 없어 사람이 확인해야 합니다.',checks:checksOf(node),
  stateId:state.id,url:state.url,viewport:state.viewport,stateLabel:state.label,screenshot:state.screenshot,
  bounds:node._bounds||null,steps:['페이지 열기',state.viewport==='mobile'?'모바일 화면 390×844':'PC 화면 1440×1000',...run.request.steps.slice(0,state.step).map(s=>`${s.action}: ${s.selector}`),'해당 요소 확인'],
  owner:'',note:'',source:'axe-core',history:[{at:now(),status:'open',note:type==='violation'?'자동 규칙 위반 발견':'사람 확인 필요'}]};
}
async function browserContext(id,headed=false){
 if(!playwright)throw Error('Playwright가 설치되지 않았습니다. 설치 스크립트를 실행하세요.');
 const profile=path.join(DATA,'browser',id);await fsp.mkdir(profile,{recursive:true});
 const options={headless:!headed,viewport:{width:1440,height:1000},ignoreHTTPSErrors:process.env.PAGECHECK_IGNORE_HTTPS_ERRORS==='1',timeout:20000};
 try{return await playwright.chromium.launchPersistentContext(profile,{...options,channel:process.env.PAGECHECK_BROWSER||'chrome'})}
 catch(e){if(process.env.PAGECHECK_BROWSER)throw e;try{return await playwright.chromium.launchPersistentContext(profile,{...options,channel:'msedge'})}catch{throw Error('Chrome 또는 Edge를 실행하지 못했습니다. 설치 여부와 실행 권한을 확인하세요.')}}
}
async function capture(run,page,url,viewport,step,label){
 const state={id:crypto.randomUUID(),url,viewport,step,label,status:'running',screenshot:null,findings:0};run.states.push(state);
 try{
  state.url=page.url();const title=await page.title();state.title=title;
  const dir=path.join(DATA,'evidence',run.id);await fsp.mkdir(dir,{recursive:true});state.screenshot=`${run.id}/${state.id}.png`;
  // 페이지 전체를 찍어 첫 화면 아래의 문제 요소도 위치를 표시할 수 있게 한다.
  const png=await page.screenshot({path:path.join(dir,state.id+'.png'),fullPage:true,animations:'disabled',timeout:30000});
  state.imageSize={width:png.readUInt32BE(16),height:png.readUInt32BE(20)};
  await page.addScriptTag({path:path.join(ROOT,'engine/vendor/axe.min.js')});
  const result=await page.evaluate(async locale=>{
   axe.configure({locale});
   const r=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']},resultTypes:['violations','incomplete','passes','inapplicable']});
   for(const rule of [...r.violations,...r.incomplete])for(const node of rule.nodes){try{const el=document.querySelector(node.target[0]);if(el){const b=el.getBoundingClientRect();node._bounds={x:b.x+scrollX,y:b.y+scrollY,width:b.width,height:b.height,page:true}}}catch{}}
   return {violations:r.violations,incomplete:r.incomplete,passes:r.passes.map(x=>x.id),inapplicable:r.inapplicable.map(x=>x.id),version:r.testEngine.version};
  },AXE_KO);
  run.engine.version=result.version;state.passedRuleIds=result.passes;state.inapplicableRuleIds=result.inapplicable;
  state.facts=await pageFacts(page);
  for(const [type,rules] of [['violation',result.violations],['review',result.incomplete]])for(const rule of rules)for(const node of rule.nodes.slice(0,40)){
   const issue=toIssue(rule,node,run,state,type);if(!run.issues.some(x=>x.fingerprint===issue.fingerprint))run.issues.push(issue);
   state.findings++;
  }
  state.status='completed';log(run,`${label} · ${viewport==='desktop'?'PC':'모바일'} 검사 완료`);
 }catch(e){state.status='error';state.error=String(e.message).slice(0,500);log(run,`${label} 검사하지 못함: ${state.error}`)}
 await persist();return state;
}
async function scan(run,input){
 let context,owned=true;run.status='running';log(run,'브라우저 검사 시작');await persist();
 try{
  if(input.sessionId){context=sessions.get(input.sessionId)?.context;owned=false;if(!context)throw Error('로그인 연결이 종료됐습니다. 로그인 연결 후 다시 검사하세요.')}
  else context=await browserContext(run.id);
  for(const url of input.urls)for(const viewport of input.viewports){
   const page=await context.newPage();await page.setViewportSize(viewport==='mobile'?{width:390,height:844}:{width:1440,height:1000});
   try{
    const response=await page.goto(url,{waitUntil:'domcontentloaded',timeout:30000});
    if(response&&response.status()>=400)throw Error(`페이지 응답 ${response.status()}`);
    await page.waitForTimeout(500);
    const redirected=new URL(page.url()).pathname;if(/\/(login|signin|sign-in|auth)(\/|$)/i.test(redirected)&&new URL(url).pathname!==redirected){throw Error('로그인 화면으로 이동했습니다. 로그인 연결 후 원래 페이지를 재검수하세요.')}
    await capture(run,page,url,viewport,0,'초기 화면');
    if(url===input.urls[0])for(let i=0;i<input.steps.length;i++){
     const s=input.steps[i];try{
      const el=page.locator(s.selector).first();if(s.action==='click')await el.click({timeout:8000});
      if(s.action==='fill')await el.fill(s.value||'',{timeout:8000});if(s.action==='press')await el.press(s.value||'Tab',{timeout:8000});
      await page.waitForTimeout(250);await capture(run,page,page.url(),viewport,i+1,s.label||`단계 ${i+1}`);
     }catch(e){run.states.push({id:crypto.randomUUID(),url,viewport,step:i+1,label:s.label||`단계 ${i+1}`,status:'error',error:`단계 실행 실패: ${e.message.slice(0,300)}`});break}
    }
   }catch(e){run.states.push({id:crypto.randomUUID(),url,viewport,step:0,label:'페이지 접근',status:'error',error:e.message.slice(0,500)});log(run,`페이지 접근 실패: ${url}`)}
   finally{await page.close().catch(()=>{})}
  }
  run.status=run.states.some(s=>s.status==='completed')?'completed':'failed';
  const baseline=runs.find(r=>r.id===input.baselineId);
  if(baseline){
   const previous=new Set(baseline.issues.map(i=>i.fingerprint));
   for(const item of baseline.issues.filter(i=>i.source==='manual'&&i.workflow!=='resolved'))if(!run.issues.some(i=>i.fingerprint===item.fingerprint))run.issues.push({...structuredClone(item),workflow:'open'});
   const current=new Set(run.issues.map(i=>i.fingerprint));
   const comparable=i=>i.source==='axe-core'&&baseline.engine.version===run.engine.version&&run.states.some(s=>s.status==='completed'&&s.viewport===i.viewport&&s.step===baseline.states.find(x=>x.id===i.stateId)?.step&&s.url===i.url&&(s.passedRuleIds?.includes(i.ruleId)||s.inapplicableRuleIds?.includes(i.ruleId)));
   run.comparison={baselineId:baseline.id,new:run.issues.filter(i=>!previous.has(i.fingerprint)).map(i=>i.fingerprint),remaining:run.issues.filter(i=>previous.has(i.fingerprint)).map(i=>i.fingerprint),
    resolved:baseline.issues.filter(i=>!current.has(i.fingerprint)&&comparable(i)).map(i=>i.fingerprint),unverified:baseline.issues.filter(i=>!current.has(i.fingerprint)&&!comparable(i)).map(i=>i.fingerprint)};
   for(const issue of run.issues){const old=baseline.issues.find(x=>x.fingerprint===issue.fingerprint);if(old){issue.owner=old.owner;issue.note=old.note}}
   for(const issue of baseline.issues){if(run.comparison.resolved.includes(issue.fingerprint)){issue.workflow='resolved';issue.history.push({at:now(),status:'resolved',note:`재검수 ${run.id}에서 동일 조건의 자동 검사로 재발견되지 않음`})}}
  }
  log(run,'검사 종료 · 자동 규칙 결과와 전체 기준 평가를 구분해 확인하세요.');
 }catch(e){run.status='failed';run.error=e.message;log(run,e.message)}
 finally{if(context&&owned)await context.close().catch(()=>{});run.updatedAt=now();await persist()}
}
async function drain(){if(busy)return;busy=true;while(queue.length){const id=queue.shift(),run=runs.find(x=>x.id===id);await scan(run,rawRequests.get(id))}busy=false}
async function jsonBody(req){let s='';for await(const c of req){s+=c;if(s.length>100000)throw Error('요청이 너무 큽니다.')}return s?JSON.parse(s):{}}
function response(res,status,body){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(body))}
const server=http.createServer(async(req,res)=>{
 try{
  const origin=req.headers.origin;
  if(!['127.0.0.1:'+PORT,'localhost:'+PORT].includes(req.headers.host)){return response(res,403,{error:'허용되지 않은 호스트입니다.'})}
  if(origin&&!allowedOrigins.has(origin))return response(res,403,{error:'허용되지 않은 화면 출처입니다.'});
  if(origin){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Methods','GET, POST, PATCH, OPTIONS');res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type');res.setHeader('Access-Control-Allow-Private-Network','true')}
  if(req.method==='OPTIONS'){res.writeHead(204);return res.end()}
  const u=new URL(req.url,ORIGIN),p=u.pathname;
  if(p==='/api/health')return response(res,200,{ok:true,version:'0.1.0',browserAvailable:!!playwright,queue:queue.length,busy});
  if(p==='/api/local-session'){
   if(origin&&origin!==ORIGIN&&origin!==`http://localhost:${PORT}`)return response(res,403,{error:'로컬 화면에서만 연결 키를 읽을 수 있습니다.'});
   if(req.headers['sec-fetch-site']==='cross-site')return response(res,403,{error:'로컬 화면에서 연결하세요.'});return response(res,200,{token:TOKEN});
  }
  if(p.startsWith('/api/')){
   if(req.headers.authorization!==`Bearer ${TOKEN}`)return response(res,401,{error:'연결 키를 확인하세요.'});
   if(p==='/api/runs'&&req.method==='GET')return response(res,200,runs.map(hydrate));
   if(p==='/api/runs'&&req.method==='POST'){const r=enqueue(normalize(await jsonBody(req)));return response(res,202,hydrate(r))}
   if(p==='/api/login'&&req.method==='POST'){
    const b=await jsonBody(req),url=safeUrl(b.url),id=crypto.randomUUID(),context=await browserContext('session-'+id,true);sessions.set(id,{context,url});
    context.on('close',()=>sessions.delete(id));const page=context.pages()[0]||await context.newPage();await page.goto(url,{waitUntil:'domcontentloaded',timeout:30000});return response(res,200,{id,url});
   }
   if(p==='/api/login/close'&&req.method==='POST'){const b=await jsonBody(req);await sessions.get(b.id)?.context.close();sessions.delete(b.id);return response(res,200,{ok:true})}
   const evidence=p.match(/^\/api\/evidence\/([a-f0-9-]+)\/([a-f0-9-]+\.png)$/);
   if(evidence){const file=path.join(DATA,'evidence',evidence[1],evidence[2]);if(!fs.existsSync(file))return response(res,404,{error:'증거 화면이 없습니다.'});res.writeHead(200,{'Content-Type':'image/png','Cache-Control':'no-store'});return fs.createReadStream(file).pipe(res)}
   const match=p.match(/^\/api\/runs\/([a-f0-9-]+)(?:\/(.*))?$/);
   if(match){
    const run=runs.find(r=>r.id===match[1]);if(!run)return response(res,404,{error:'검수 기록이 없습니다.'});const action=match[2];
    if(!action&&req.method==='GET')return response(res,200,hydrate(run));
    if(action==='recheck'&&req.method==='POST'){
     const input=rawRequests.get(run.id);if(!input&&run.request.steps.some(s=>s.action==='fill'))return response(res,400,{error:'엔진 재시작 후 입력값이 제거됐습니다. 새 검수에서 테스트 단계를 다시 입력하세요.'});
     const override=await jsonBody(req);return response(res,202,hydrate(enqueue(normalize({...input||run.request,sessionId:input?.sessionId||null,...override,baselineId:run.id}))));
    }
    if(action==='review'&&req.method==='POST'){
     const b=await jsonBody(req);if(!CRITERIA.some(c=>c.sc_id===b.scId)||!['pass','fail','inapplicable','needs-review'].includes(b.outcome)||!String(b.note||'').trim()||!String(b.reviewer||'').trim())throw Error('기준, 판정, 검토자와 근거를 입력하세요.');
     if(['pass','inapplicable'].includes(b.outcome)&&run.issues.some(i=>i.scIds.includes(b.scId)&&i.type==='violation'&&i.workflow!=='resolved'))throw Error('미해결 위반이 있어 통과·비적용으로 기록할 수 없습니다.');
     if(b.outcome==='fail'){
      const id=hash('manual:'+b.scId),existing=run.issues.find(i=>i.id===id),criterion=CRITERIA.find(c=>c.sc_id===b.scId);
      if(existing){existing.workflow='open';existing.note=String(b.note);existing.history.push({at:now(),status:'open',note:'기준 전체 평가에서 문제 확인'})}
      else run.issues.push({id,fingerprint:id,ruleId:'manual-'+b.scId,title:criterion.title_ko_unofficial,description:criterion.audit_focus_ko,impact:'moderate',type:'violation',workflow:'open',scIds:[b.scId],helpUrl:criterion.version_source_urls['2.2'],selector:'기준 전체 평가',html:'',explanation:String(b.note),stateId:null,url:run.request.urls[0],viewport:'desktop',stateLabel:'사람 검토',screenshot:null,bounds:null,steps:['해당 검수 범위의 평가 근거 확인'],owner:String(b.reviewer),note:String(b.note),source:'manual',history:[{at:now(),status:'open',note:'기준 전체 평가에서 문제 확인'}]});
     }
     run.reviews[b.scId]={outcome:b.outcome,note:String(b.note).slice(0,2000),reviewer:String(b.reviewer).slice(0,100),at:now()};await persist();return response(res,200,hydrate(run));
    }
    if(action?.startsWith('issues/')&&req.method==='PATCH'){
     const issue=run.issues.find(i=>i.id===action.split('/')[1]);if(!issue)throw Error('문제를 찾을 수 없습니다.');const b=await jsonBody(req);
     if(b.workflow){if(!['open','confirmed','planned','inprogress','retest','resolved'].includes(b.workflow))throw Error('올바른 상태를 선택하세요.');if(b.workflow==='resolved'&&issue.type==='violation'&&issue.source!=='manual')throw Error('자동 위반은 재검수에서 해결 여부를 확인하세요.');if(b.workflow==='resolved'&&!b.note?.trim())throw Error('검토 근거를 입력하세요.');issue.workflow=b.workflow;issue.history.push({at:now(),status:b.workflow,note:String(b.note||'').slice(0,2000)})}
     issue.owner=String(b.owner??issue.owner).slice(0,100);issue.note=String(b.note??issue.note).slice(0,2000);await persist();return response(res,200,hydrate(run));
    }
    if(action==='export')return response(res,200,hydrate(run));
   }
   return response(res,404,{error:'지원하지 않는 요청입니다.'});
  }
  const relative=decodeURIComponent(p==='/'?'index.html':p.slice(1));const file=path.resolve(ROOT,'dist',relative);
  if(!file.startsWith(path.join(ROOT,'dist')+path.sep))return response(res,403,{error:'접근할 수 없습니다.'});
  if(!fs.existsSync(file)||!fs.statSync(file).isFile())return response(res,404,{error:'파일을 찾을 수 없습니다.'});
  const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json; charset=utf-8','.zip':'application/zip'};
  res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Cache-Control':'no-cache'});fs.createReadStream(file).pipe(res);
 }catch(e){response(res,400,{error:e.message||'요청을 처리하지 못했습니다.'})}
});
server.listen(PORT,'127.0.0.1',()=>console.log(`PageCheck 실행: ${ORIGIN}\n연결 키: ${TOKEN}\n검수 기록과 화면은 이 PC의 data 폴더에 저장됩니다.`));
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,async()=>{await persist();for(const s of sessions.values())await s.context.close().catch(()=>{});server.close();process.exit(0)});
