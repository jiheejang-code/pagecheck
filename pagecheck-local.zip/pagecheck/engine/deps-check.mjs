import {createRequire} from 'node:module';
import path from 'node:path';
import os from 'node:os';
let found=false;
try{createRequire(import.meta.url)('playwright');found=true}catch{}
if(!found)try{createRequire(path.join(os.homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/package.json'))('playwright');found=true}catch{}
console.log(found?'브라우저 검사 모듈을 사용할 수 있습니다.':'브라우저 검사 모듈 설치가 필요합니다.');
process.exit(found?0:1);
