// 키보드·확대 자동 확인. axe 규칙이 못 보는 부분을 실제 조작으로 확인하고 증거 화면을 남긴다.
// 여기서 찾은 것은 모두 '사람 확인 필요' 후보이며, 문제가 없다고 기준을 통과시키지 않는다.
import path from 'node:path';

const MAX_TABS=80,MAX_FINDINGS=15;
export const CHECK_KINDS={
 keyboard:{label:'키보드 Tab 이동',sc:['2.1.1','2.1.2','2.4.1','2.4.3','2.4.7','2.4.11','3.2.1'],viewport:{width:1440,height:1000}},
 reflow:{label:'320px 너비(리플로)',sc:['1.4.10'],viewport:{width:320,height:800}},
 zoom:{label:'200% 확대(720px 너비)',sc:['1.4.4'],viewport:{width:720,height:500}},
 spacing:{label:'텍스트 간격 넓히기',sc:['1.4.12'],viewport:{width:1440,height:1000}}
};
const SPACING_CSS='*{line-height:1.5!important;letter-spacing:.12em!important;word-spacing:.16em!important}p{margin-bottom:2em!important}';

// 페이지 안에서 쓰는 도구. 이동할 때마다 다시 넣는다.
function helpers(){
 const pathOf=el=>{
  if(el.id&&document.querySelectorAll('#'+CSS.escape(el.id)).length===1)return '#'+CSS.escape(el.id);
  const parts=[];let e=el;
  while(e&&e.nodeType===1&&e!==document.body&&parts.length<5){
   if(e.id&&document.querySelectorAll('#'+CSS.escape(e.id)).length===1){parts.unshift('#'+CSS.escape(e.id));break}
   const same=e.parentElement?[...e.parentElement.children].filter(x=>x.tagName===e.tagName):[];
   parts.unshift(e.tagName.toLowerCase()+(same.length>1?`:nth-of-type(${same.indexOf(e)+1})`:''));e=e.parentElement;
  }
  return parts.join(' > ');
 };
 const rectOf=el=>{const r=el.getBoundingClientRect();return {x:r.left+scrollX,y:r.top+scrollY,width:r.width,height:r.height}};
 const nameOf=el=>(el.getAttribute('aria-label')||el.innerText||el.value||el.getAttribute('title')||el.getAttribute('alt')||el.getAttribute('placeholder')||'').trim().replace(/\s+/g,' ').slice(0,60);
 const html=el=>el.outerHTML.slice(0,300);
 const look=el=>{if(!el)return '';const s=getComputedStyle(el);return [s.outlineStyle,s.outlineWidth,s.outlineColor,s.boxShadow,s.borderColor,s.borderWidth,s.backgroundColor,s.color,s.textDecorationLine].join('|')};
 const active=()=>{let el=document.activeElement;while(el&&el.shadowRoot&&el.shadowRoot.activeElement)el=el.shadowRoot.activeElement;return el&&el!==document.body&&el!==document.documentElement?el:null};
 window.__pc={
  focusInfo(){
   const el=active();if(!el)return null;
   const r=el.getBoundingClientRect(),s=getComputedStyle(el);
   const inView=r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth&&r.width>0&&r.height>0;
   const pts=[[r.left+r.width/2,r.top+r.height/2],[r.left+2,r.top+2],[r.right-2,r.top+2],[r.left+2,r.bottom-2],[r.right-2,r.bottom-2]];
   const hits=inView?pts.filter(([x,y])=>{const h=document.elementFromPoint(x,y);return h&&(h===el||el.contains(h)||h.contains(el))}).length:0;
   // 포커스 상태와 포커스를 뺀 상태의 모양을 비교한다. 부모 모양이 바뀌는 경우(:focus-within)도 본다.
   const on=look(el)+look(el.parentElement),outline=s.outlineStyle!=='none'&&parseFloat(s.outlineWidth)>0;
   el.blur();const off=look(el)+look(el.parentElement);el.focus({preventScroll:true});
   return {selector:pathOf(el),tag:el.tagName.toLowerCase(),name:nameOf(el),href:el.getAttribute('href')||'',html:html(el),rect:rectOf(el),inView,hits,indicator:outline||on!==off,iframe:el.tagName==='IFRAME'};
  },
  // 마우스 커서는 손 모양인데 키보드로 갈 수 없는 요소. 바깥쪽 요소만 센다.
  pointerOnly(){
   const focusable='a[href],button,input,select,textarea,summary,label,iframe,[tabindex],[contenteditable=""],[contenteditable=true]';
   return [...document.querySelectorAll('body *')].filter(el=>{
    if(getComputedStyle(el).cursor!=='pointer'||el.closest(focusable)||el.querySelector(focusable))return false;
    if(el.parentElement&&getComputedStyle(el.parentElement).cursor==='pointer')return false;
    const r=el.getBoundingClientRect();return r.width>0&&r.height>0;
   }).slice(0,20).map(el=>({selector:pathOf(el),name:nameOf(el),html:html(el),rect:rectOf(el)}));
  },
  // 글자가 상자에 잘려 보이지 않는 요소
  clipped(){
   return [...document.querySelectorAll('body *')].filter(el=>{
    const s=getComputedStyle(el);if(!/hidden|clip/.test(s.overflowX+s.overflowY)&&s.textOverflow!=='ellipsis')return false;
    if(![...el.childNodes].some(n=>n.nodeType===3&&n.textContent.trim())&&!el.innerText?.trim())return false;
    return el.scrollHeight>el.clientHeight+2&&/hidden|clip/.test(s.overflowY)||el.scrollWidth>el.clientWidth+2&&(/hidden|clip/.test(s.overflowX)||s.textOverflow==='ellipsis');
   }).map(el=>({selector:pathOf(el),name:nameOf(el),html:html(el),rect:rectOf(el)}));
  },
  // 화면 오른쪽 밖으로 나간 요소 중 바깥쪽 것. 가로 스크롤 상자 안의 요소는 뺀다.
  overflow(){
   const w=document.documentElement.clientWidth,out=el=>el.getBoundingClientRect().right>w+1;
   const scrollBox=el=>{for(let p=el.parentElement;p&&p!==document.body;p=p.parentElement)if(/auto|scroll/.test(getComputedStyle(p).overflowX))return true;return false};
   const list=[...document.querySelectorAll('body *')].filter(el=>{const r=el.getBoundingClientRect();return r.width>0&&r.height>0&&out(el)&&!scrollBox(el)&&!(el.parentElement&&el.parentElement!==document.body&&out(el.parentElement))});
   return {scrollWidth:document.documentElement.scrollWidth,width:w,items:list.slice(0,10).map(el=>({selector:pathOf(el),name:nameOf(el),html:html(el),rect:rectOf(el)}))};
  },
  landmarks(){return {main:document.querySelectorAll('main,[role=main]').length,nav:document.querySelectorAll('nav,[role=navigation]').length,headings:document.querySelectorAll('h1,h2,h3,h4,h5,h6,[role=heading]').length}},
  // 포커스 순서 번호를 화면에 그린다. 증거 화면을 찍은 뒤 지운다.
  drawOrder(stops){
   const layer=document.createElement('div');layer.id='__pc-order';layer.style.cssText='position:absolute;left:0;top:0;width:0;height:0;z-index:2147483647;pointer-events:none';
   stops.forEach((s,i)=>{const box=document.createElement('div');box.style.cssText=`position:absolute;left:${s.rect.x}px;top:${s.rect.y}px;width:${s.rect.width}px;height:${s.rect.height}px;outline:2px solid ${s.problem?'#c62828':'#1565c0'}`;
    const tag=document.createElement('span');tag.textContent=i+1;tag.style.cssText=`position:absolute;left:-2px;top:-20px;min-width:18px;padding:1px 4px;font:bold 12px/16px Arial,sans-serif;color:#fff;background:${s.problem?'#c62828':'#1565c0'};border-radius:3px;text-align:center`;
    box.append(tag);layer.append(box)});
   document.documentElement.append(layer);
  },
  clearOrder(){document.getElementById('__pc-order')?.remove()}
 };
}

async function open(context,url,viewport){
 const page=await context.newPage();await page.setViewportSize(viewport);
 const response=await page.goto(url,{waitUntil:'domcontentloaded',timeout:30000});
 if(response&&response.status()>=400)throw Error(`페이지 응답 ${response.status()}`);
 await page.waitForTimeout(500);await page.evaluate(helpers);return page;
}
async function shoot(page,dir,id){const png=await page.screenshot({path:path.join(dir,id+'.png'),fullPage:true,animations:'disabled',timeout:30000});return {width:png.readUInt32BE(16),height:png.readUInt32BE(20)}}

// 결과: notes={sc:문장}, findings=[{type,sc,title,explanation,selector,name,html,rect}]
async function keyboard(page){
 const startUrl=page.url(),stops=[],findings=[],notes={};let popups=0,trap=null,changed=false;
 page.on('popup',p=>{popups++;p.close().catch(()=>{})});
 for(let i=0;i<MAX_TABS;i++){
  await page.keyboard.press('Tab');await page.waitForTimeout(60);
  if(page.url()!==startUrl||popups){changed=true;break}
  const info=await page.evaluate(()=>window.__pc.focusInfo()).catch(()=>null);
  if(!info){if(stops.length)break;continue}
  if(info.iframe){stops.push(info);continue}
  if(stops.length&&info.selector===stops[0].selector)break;
  const seen=stops.findIndex(s=>s.selector===info.selector);
  if(seen>0){trap={from:stops[seen],loop:stops.slice(seen)};break}
  stops.push(info);
 }
 const reachedEnd=!trap&&!changed&&stops.length<MAX_TABS;
 // 다른 주소로 이동했으면 원래 페이지로 돌아가 나머지 확인과 순서 표시를 한다.
 if(page.url()!==startUrl){await page.goto(startUrl,{waitUntil:'domcontentloaded',timeout:30000});await page.waitForTimeout(500);await page.evaluate(helpers)}
 for(const s of stops){
  if(s.iframe)continue;
  if(!s.inView){s.problem=true;findings.push({type:'focus-offscreen',sc:['2.4.7'],title:'포커스가 화면 밖에 있음',explanation:`Tab으로 이 요소(${s.name||s.tag})에 왔을 때 화면에 보이지 않았습니다. 화면 밖에 숨긴 요소이거나 크기가 0일 수 있습니다.`,...s})}
  else if(s.hits===0){s.problem=true;findings.push({type:'focus-obscured',sc:['2.4.11'],title:'포커스된 요소가 다른 요소에 가려짐',explanation:`Tab으로 이 요소(${s.name||s.tag})에 왔을 때 다른 요소(고정 헤더, 팝업 등)가 위를 완전히 덮고 있었습니다.`,...s})}
  else if(!s.indicator){s.problem=true;findings.push({type:'focus-visible',sc:['2.4.7'],title:'포커스 표시가 보이지 않을 수 있음',explanation:`이 요소(${s.name||s.tag})는 포커스를 받아도 테두리·그림자·색이 바뀌지 않았습니다. 화면에서 포커스 위치를 알 수 있는지 확인하세요.`,...s})}
 }
 if(trap)findings.push({type:'trap',sc:['2.1.2'],title:'Tab 이동이 일부 요소 안에서만 반복됨',explanation:`Tab을 계속 눌렀더니 페이지 끝으로 가지 않고 ${trap.loop.length}개 요소 사이만 반복했습니다(${trap.loop.slice(0,4).map(s=>s.name||s.tag).join(' → ')}). 빠져나갈 방법이 안내돼 있는지 확인하세요.`,...trap.from});
 // 주소가 바뀐 경우 마지막으로 기록한 요소 다음 요소가 원인이다. 그 요소는 이미 사라졌으므로 직전 요소를 함께 알린다.
 if(changed){const last=stops.at(-1);findings.push({type:'context-change',sc:['3.2.1'],title:'Tab 이동만으로 페이지가 바뀜',explanation:`Tab으로 포커스만 옮겼는데 ${popups?'새 창이 열렸습니다':'다른 주소로 이동했습니다'}. ${last?`‘${last.name||last.tag}’ 다음 요소에서 일어났습니다.`:'첫 Tab에서 일어났습니다.'}`,selector:last?.selector||'페이지',name:last?.name||'',html:last?.html||'',rect:null})}
 const pointerOnly=await page.evaluate(()=>window.__pc.pointerOnly()).catch(()=>[]);
 for(const p of pointerOnly)findings.push({type:'pointer-only',sc:['2.1.1'],title:'마우스로만 누를 수 있는 요소 후보',explanation:`이 요소(${p.name||'이름 없음'})는 마우스를 올리면 손 모양 커서가 되지만 Tab으로 갈 수 없습니다. 클릭하면 기능이 실행된다면 키보드로도 쓸 수 있어야 합니다.`,...p});
 const lm=await page.evaluate(()=>window.__pc.landmarks()).catch(()=>({main:0,nav:0,headings:0}));
 const first=stops[0];
 notes['2.1.1']=`Tab으로 ${stops.length}곳에 이동했습니다. 마우스로만 누를 수 있는 요소 후보 ${pointerOnly.length}개.`;
 notes['2.1.2']=trap?'Tab 이동이 일부 요소 안에서만 반복됐습니다.':reachedEnd?'Tab을 계속 눌러 페이지 끝까지 갔습니다. 갇힌 곳은 발견되지 않았습니다.':`Tab ${MAX_TABS}번 안에 페이지 끝에 닿지 못했습니다.`;
 notes['2.4.1']=first&&/^#./.test(first.href)?`첫 Tab 위치가 같은 페이지로 가는 링크입니다(‘${first.name}’). 눌렀을 때 본문으로 가는지 확인하세요.`:`첫 Tab 위치에 건너뛰기 링크가 없습니다${first?`(‘${first.name||first.tag}’)`:''}. 랜드마크 main ${lm.main}개·nav ${lm.nav}개, 제목 ${lm.headings}개.`;
 notes['2.4.3']=`포커스 순서를 번호로 표시한 화면을 남겼습니다. 번호가 읽는 순서와 맞는지 보세요.`;
 notes['2.4.7']=`포커스 표시가 바뀌지 않은 요소 ${findings.filter(f=>f.type==='focus-visible').length}개, 화면 밖 포커스 ${findings.filter(f=>f.type==='focus-offscreen').length}개.`;
 notes['2.4.11']=`다른 요소에 완전히 가려진 포커스 ${findings.filter(f=>f.type==='focus-obscured').length}개.`;
 notes['3.2.1']=changed?'Tab 이동 중 페이지가 바뀌었습니다.':'Tab 이동 중 주소가 바뀌거나 새 창이 열리지 않았습니다.';
 await page.evaluate(()=>window.scrollTo(0,0));await page.evaluate(s=>window.__pc.drawOrder(s),stops.filter(s=>!s.iframe).map(s=>({rect:s.rect,problem:!!s.problem})));
 return {notes,findings,summary:{stops:stops.length,reachedEnd}};
}
async function layout(page,kind,baseline){
 const o=await page.evaluate(()=>window.__pc.overflow());
 const clipped=(await page.evaluate(()=>window.__pc.clipped())).filter(c=>!baseline.has(c.selector));
 const sc=kind==='reflow'?'1.4.10':'1.4.4',where=kind==='reflow'?'320px 너비':'200% 확대(720px 너비)';
 const findings=[];
 if(o.scrollWidth>o.width+1)for(const item of o.items)findings.push({type:kind+'-overflow',sc:[sc],title:`${where}에서 화면 밖으로 나감`,explanation:`이 요소(${item.name||'이름 없음'})가 화면 오른쪽 밖으로 나가 가로 스크롤이 생깁니다(페이지 너비 ${o.scrollWidth}px / 화면 ${o.width}px). 표·지도처럼 가로 배치가 꼭 필요한 내용인지 확인하세요.`,...item});
 for(const c of clipped.slice(0,MAX_FINDINGS))findings.push({type:kind+'-clip',sc:[sc],title:`${where}에서 글자가 잘림`,explanation:`이 요소(${c.name||'이름 없음'})의 글자가 상자 밖으로 넘쳐 잘립니다. PC 기본 화면에서는 잘리지 않았습니다.`,...c});
 const scroll=o.scrollWidth>o.width+1?`가로 스크롤이 생깁니다(페이지 너비 ${o.scrollWidth}px).`:'가로 스크롤이 생기지 않았습니다.';
 return {notes:{[sc]:`${where}: ${scroll} 새로 잘린 글자 ${clipped.length}곳.`},findings,summary:{scrollWidth:o.scrollWidth,width:o.width,clipped:clipped.length}};
}
async function spacing(page,baseline){
 await page.addStyleTag({content:SPACING_CSS}).catch(()=>page.evaluate(css=>{const s=document.createElement('style');s.textContent=css;document.head.append(s)},SPACING_CSS));
 await page.waitForTimeout(300);
 const clipped=(await page.evaluate(()=>window.__pc.clipped())).filter(c=>!baseline.has(c.selector));
 return {notes:{'1.4.12':`줄 간격 1.5배·글자 간격 0.12배·단어 간격 0.16배·문단 간격 2배를 적용했습니다. 새로 잘린 글자 ${clipped.length}곳.`},
  findings:clipped.slice(0,MAX_FINDINGS).map(c=>({type:'spacing-clip',sc:['1.4.12'],title:'텍스트 간격을 넓히면 글자가 잘림',explanation:`간격을 넓혔더니 이 요소(${c.name||'이름 없음'})의 글자가 상자 밖으로 넘쳐 잘립니다. 높이·너비를 고정하지 않았는지 확인하세요.`,...c})),summary:{clipped:clipped.length}};
}

// 한 주소에 대해 네 가지를 차례로 확인한다. 하나가 실패해도 나머지는 계속한다.
export async function interactionChecks(context,url,dir,newId){
 const results=[];let baseline=new Set();
 for(const kind of Object.keys(CHECK_KINDS)){
  const def=CHECK_KINDS[kind],check={id:newId(),kind,label:def.label,url,viewport:def.viewport,status:'running',screenshot:null,imageSize:null,notes:{},summary:null,error:null};let page,findings=[];
  try{
   page=await open(context,url,def.viewport);check.url=page.url();
   if(kind==='keyboard')baseline=new Set((await page.evaluate(()=>window.__pc.clipped())).map(c=>c.selector));
   const r=kind==='keyboard'?await keyboard(page):kind==='spacing'?await spacing(page,baseline):await layout(page,kind,baseline);
   check.imageSize=await shoot(page,dir,check.id);check.screenshot=check.id+'.png';
   check.notes=r.notes;check.summary=r.summary;findings=r.findings;check.status='completed';
  }catch(e){check.status='error';check.error=String(e.message).slice(0,300)}
  finally{await page?.close().catch(()=>{})}
  results.push({check,findings});
 }
 return results;
}
