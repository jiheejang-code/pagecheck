import readline from 'node:readline/promises';
const input = readline.createInterface({input:process.stdin,output:process.stdout});
console.log('GitHub Pages에 표시되는 온라인 검수 화면 주소를 입력하세요.');
try {
  const value = (await input.question('온라인 주소: ')).trim();
  const url = new URL(value);
  if (url.protocol !== 'https:' || url.username || url.password || url.port || !url.hostname.endsWith('.github.io')) throw new Error('https://사용자이름.github.io/저장소이름/ 형식의 주소를 입력하세요.');
  process.env.PAGECHECK_ALLOWED_ORIGINS = url.origin;
  console.log(`연결을 허용한 출처: ${url.origin}`);
  input.close();
  await import('./server.mjs');
} catch (error) {
  input.close();
  console.error(error.message);
  process.exitCode = 1;
}
