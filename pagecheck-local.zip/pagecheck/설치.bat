@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PAGECHECK_NODE=node.exe"
where node.exe >nul 2>nul
if errorlevel 1 set "PAGECHECK_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
"%PAGECHECK_NODE%" engine\deps-check.mjs
if errorlevel 1 (
  where npm.cmd >nul 2>nul
  if errorlevel 1 (
    echo Install Node.js 20+ from https://nodejs.org/ and try again.
    pause
    exit /b 1
  )
  call npm.cmd install --omit=dev
  if errorlevel 1 (
    echo Installation failed. Check your network connection.
    pause
    exit /b 1
  )
)
echo Ready. Run 시작.bat and open http://127.0.0.1:47831
pause
