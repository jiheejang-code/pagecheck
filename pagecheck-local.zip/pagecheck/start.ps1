﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$taskNodeCommand = Get-Command node -ErrorAction SilentlyContinue
$taskBundledNode = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
if ($taskNodeCommand) { $taskNode = $taskNodeCommand.Source }
elseif (Test-Path -LiteralPath $taskBundledNode) { $taskNode = $taskBundledNode }
else { throw 'Node.js 20 이상을 설치하고 설치.bat를 먼저 실행하세요.' }
Write-Host 'PageCheck 실행 중. 아래 주소를 브라우저에서 여세요.' -ForegroundColor Green
Write-Host 'http://127.0.0.1:47831'
& $taskNode 'engine/server.mjs'
