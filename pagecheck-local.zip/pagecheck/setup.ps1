﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$taskNodeCommand = Get-Command node -ErrorAction SilentlyContinue
$taskBundledNode = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
if ($taskNodeCommand) { $taskNode = $taskNodeCommand.Source }
elseif (Test-Path -LiteralPath $taskBundledNode) { $taskNode = $taskBundledNode }
else { throw 'Node.js 20 이상을 설치한 뒤 다시 실행하세요: https://nodejs.org/' }
$env:PATH = (Split-Path -Parent $taskNode) + ';' + $env:PATH
& $taskNode 'engine/deps-check.mjs'
if ($LASTEXITCODE -ne 0) {
    $taskNpm = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if (-not $taskNpm) { throw 'npm을 찾을 수 없습니다. Node.js LTS 설치 후 다시 실행하세요.' }
    & $taskNpm.Source install --omit=dev
    if ($LASTEXITCODE -ne 0) { throw '의존성 설치 실패. 네트워크 연결을 확인하세요.' }
}
Write-Host '설치가 끝났습니다. 시작.bat를 실행하고 http://127.0.0.1:47831 을 여세요.' -ForegroundColor Green
Write-Host '실제 페이지 검사를 위해 Chrome 또는 Edge가 설치되어 있어야 합니다.'
