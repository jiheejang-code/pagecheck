@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PAGECHECK_NODE=node.exe"
where node.exe >nul 2>nul
if errorlevel 1 set "PAGECHECK_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
"%PAGECHECK_NODE%" engine\online-launch.mjs
pause
